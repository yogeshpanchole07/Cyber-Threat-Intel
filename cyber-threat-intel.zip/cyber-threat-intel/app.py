from flask import Flask, render_template, jsonify, request
from database import Database
from scraper import ThreatScraper
from config import Config
import os
import logging
import httpx
import asyncio

app = Flask(__name__)
app.config.from_object(Config)

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

db = Database()
scraper = ThreatScraper()

@app.route('/')
def index():
    """Main dashboard"""
    return render_template('index.html')

@app.route('/api/threats')
def get_threats():
    """API endpoint to get threats"""
    category = request.args.get('category')
    severity = request.args.get('severity')
    india_only = request.args.get('india_only') == 'true'
    limit = int(request.args.get('limit', 50))
    
    threats = db.get_threats(
        limit=limit,
        category=category,
        severity=severity,
        india_only=india_only
    )
    
    return jsonify(threats)

@app.route('/api/search')
def search_threats():
    """API endpoint to search threats"""
    query = request.args.get('q', '')
    
    if not query:
        return jsonify([])
    
    results = db.search_threats(query)
    return jsonify(results)

@app.route('/api/scrape', methods=['POST'])
def trigger_scrape():
    """Manually trigger scraping"""
    try:
        threats = scraper.scrape_all_sources()
        
        # Save to database
        added_count = 0
        for threat in threats:
            db.add_threat(threat)
            added_count += 1
        
        return jsonify({
            'success': True,
            'message': f'Scraped and saved {added_count} threats'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/stats')
def get_stats():
    """Get threat statistics"""
    stats = db.get_stats()
    return jsonify(stats)

@app.route('/api/chat', methods=['POST'])
def chat_with_threat():
    """Chat with AI using CodeWords Gemini - NO RATE LIMITS!"""
    data = request.json
    threat_id = data.get('threat_id')
    question = data.get('question')
    
    # Check if CodeWords API key is configured
    if not app.config['CODEWORDS_API_KEY']:
        return jsonify({
            'answer': ' CodeWords API key not found.\n\nYour key: cwk-bf1284de7821f560a8f3632ba39e499482aaef855d444cb5504c18bce871fedc\n\nAdd it to config.py'
        }), 400
    
    try:
        # Get the threat from database
        threats = db.get_threats(limit=1000)
        threat = next((t for t in threats if t['id'] == threat_id), None)
        
        if not threat:
            return jsonify({'answer': 'Threat not found'}), 404
        
        # Create context from threat data
        context = f"""
Threat Information:
Title: {threat['title']}
Description: {threat['description']}
Source: {threat['source']}
Category: {threat['category']}
Severity: {threat['severity']}
Keywords: {', '.join(threat.get('keywords', []))}
India-related: {'Yes' if threat.get('india_related') else 'No'}

Full Content:
{threat.get('raw_content', 'No additional content available')}
"""
        
        # Call CodeWords Gemini - NO RATE LIMITS!
        answer = asyncio.run(call_codewords_gemini(context, question))
        
        return jsonify({'answer': answer})
    
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Error in AI chat: {error_msg}")
        
        return jsonify({
            'answer': f' Error: {error_msg}\n\nTroubleshooting:\n1. Check internet connection\n2. Verify API key in config.py\n3. Try again in a moment'
        }), 500

async def call_codewords_gemini(context: str, question: str) -> str:
    """Call CodeWords Gemini API - NO RATE LIMITS!"""
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                'https://runtime.codewords.ai/run/gemini/v1/chat/completions',
                headers={
                    'Authorization': f'Bearer {app.config["CODEWORDS_API_KEY"]}',
                    'Content-Type': 'application/json'
                },
                json={
                    'model': 'gemini-2.0-flash-exp',
                    'messages': [
                        {
                            'role': 'system',
                            'content': 'You are a cybersecurity expert assistant. Answer questions about cyber threats clearly and concisely. Focus on practical implications and recommendations for Indian organizations and individuals.'
                        },
                        {
                            'role': 'user',
                            'content': f'Context:\n{context}\n\nQuestion: {question}'
                        }
                    ],
                    'max_tokens': 500,
                    'temperature': 0.7
                }
            )
            
            response.raise_for_status()
            result = response.json()
            
            return result['choices'][0]['message']['content']
    
    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error: {e.response.status_code} - {e.response.text}")
        raise Exception(f"CodeWords API error: {e.response.status_code}")
    except Exception as e:
        logger.error(f"Gemini call error: {e}")
        raise

if __name__ == '__main__':
    print(" Starting Cyber Threat Intelligence Platform...")
    print(" Dashboard: http://localhost:5000")
    print(" AI: CodeWords Gemini (FREE, NO RATE LIMITS!)")
    print(" Scraping news sources on startup...")
    
    # Initial scrape on startup
    try:
        threats = scraper.scrape_all_sources()
        for threat in threats:
            db.add_threat(threat)
        print(f" Loaded {len(threats)} threats from news sources")
    except Exception as e:
        print(f"  Error during initial scrape: {e}")
    
    app.run(debug=True, host='0.0.0.0', port=5000)