import mysql.connector
from mysql.connector import Error, pooling
import json
from datetime import datetime
from config import Config
import logging

logger = logging.getLogger(__name__)

class Database:
    def __init__(self):
        self.config = {
            'host': Config.MYSQL_HOST,
            'port': Config.MYSQL_PORT,
            'user': Config.MYSQL_USER,
            'password': Config.MYSQL_PASSWORD,
            'database': Config.MYSQL_DATABASE,
            'charset': 'utf8mb4',
            'collation': 'utf8mb4_unicode_ci'
        }
        
        # Create connection pool
        try:
            self.pool = mysql.connector.pooling.MySQLConnectionPool(
                pool_name="threat_pool",
                pool_size=5,
                **self.config
            )
            logger.info("MySQL connection pool created successfully")
        except Error as e:
            logger.error(f"Error creating connection pool: {e}")
            # Fallback to direct connection
            self.pool = None
        
        self.init_db()
    
    def get_connection(self):
        """Get connection from pool or create new one"""
        try:
            if self.pool:
                return self.pool.get_connection()
            else:
                return mysql.connector.connect(**self.config)
        except Error as e:
            logger.error(f"Error getting connection: {e}")
            raise
    
    def init_db(self):
        """Initialize database and create tables"""
        try:
            # First, create database if it doesn't exist
            temp_config = self.config.copy()
            temp_config.pop('database')
            
            conn = mysql.connector.connect(**temp_config)
            cursor = conn.cursor()
            
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {Config.MYSQL_DATABASE} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
            logger.info(f"Database {Config.MYSQL_DATABASE} created or already exists")
            
            cursor.close()
            conn.close()
            
            # Now create tables
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS threats (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    title VARCHAR(500) NOT NULL,
                    description TEXT,
                    source VARCHAR(255),
                    url VARCHAR(1000),
                    published_date DATETIME,
                    scraped_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    category VARCHAR(100),
                    severity VARCHAR(50),
                    keywords JSON,
                    india_related BOOLEAN DEFAULT FALSE,
                    raw_content MEDIUMTEXT,
                    INDEX idx_category (category),
                    INDEX idx_severity (severity),
                    INDEX idx_india (india_related),
                    INDEX idx_scraped_date (scraped_date),
                    FULLTEXT INDEX idx_fulltext (title, description)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            conn.commit()
            logger.info("Threats table created or already exists")
            
            cursor.close()
            conn.close()
            
        except Error as e:
            logger.error(f"Error initializing database: {e}")
            raise
    
    def add_threat(self, threat_data):
        """Add a new threat to database"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Convert published_date string to datetime
            published_date = threat_data.get('published_date')
            if isinstance(published_date, str):
                try:
                    published_date = datetime.fromisoformat(published_date.replace('Z', '+00:00'))
                except:
                    published_date = datetime.now()
            
            cursor.execute('''
                INSERT INTO threats (
                    title, description, source, url, published_date,
                    category, severity, keywords, india_related, raw_content
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ''', (
                threat_data.get('title'),
                threat_data.get('description'),
                threat_data.get('source'),
                threat_data.get('url'),
                published_date,
                threat_data.get('category'),
                threat_data.get('severity'),
                json.dumps(threat_data.get('keywords', [])),
                threat_data.get('india_related', False),
                threat_data.get('raw_content')
            ))
            
            conn.commit()
            threat_id = cursor.lastrowid
            
            cursor.close()
            conn.close()
            
            return threat_id
            
        except Error as e:
            logger.error(f"Error adding threat: {e}")
            return None
    
    def get_threats(self, limit=50, category=None, severity=None, india_only=False):
        """Get threats with optional filters"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor(dictionary=True)
            
            query = "SELECT * FROM threats WHERE 1=1"
            params = []
            
            if category:
                query += " AND category = %s"
                params.append(category)
            
            if severity:
                query += " AND severity = %s"
                params.append(severity)
            
            if india_only:
                query += " AND india_related = TRUE"
            
            query += " ORDER BY scraped_date DESC LIMIT %s"
            params.append(limit)
            
            cursor.execute(query, params)
            threats = cursor.fetchall()
            
            # Parse JSON keywords
            for threat in threats:
                if threat['keywords']:
                    threat['keywords'] = json.loads(threat['keywords']) if isinstance(threat['keywords'], str) else threat['keywords']
                else:
                    threat['keywords'] = []
                
                # Convert datetime to string for JSON serialization
                if threat['published_date']:
                    threat['published_date'] = threat['published_date'].isoformat()
                if threat['scraped_date']:
                    threat['scraped_date'] = threat['scraped_date'].isoformat()
            
            cursor.close()
            conn.close()
            
            return threats
            
        except Error as e:
            logger.error(f"Error getting threats: {e}")
            return []
    
    def search_threats(self, query):
        """Search threats by keyword using FULLTEXT search"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor(dictionary=True)
            
            # Use FULLTEXT search for better performance
            cursor.execute('''
                SELECT * FROM threats 
                WHERE MATCH(title, description) AGAINST(%s IN NATURAL LANGUAGE MODE)
                   OR keywords LIKE %s
                ORDER BY scraped_date DESC
                LIMIT 50
            ''', (query, f'%{query}%'))
            
            threats = cursor.fetchall()
            
            # Parse JSON and convert datetime
            for threat in threats:
                if threat['keywords']:
                    threat['keywords'] = json.loads(threat['keywords']) if isinstance(threat['keywords'], str) else threat['keywords']
                else:
                    threat['keywords'] = []
                
                if threat['published_date']:
                    threat['published_date'] = threat['published_date'].isoformat()
                if threat['scraped_date']:
                    threat['scraped_date'] = threat['scraped_date'].isoformat()
            
            cursor.close()
            conn.close()
            
            return threats
            
        except Error as e:
            logger.error(f"Error searching threats: {e}")
            return []
    
    def get_stats(self):
        """Get statistics about threats"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor(dictionary=True)
            
            stats = {}
            
            # Total threats
            cursor.execute("SELECT COUNT(*) as count FROM threats")
            stats['total_threats'] = cursor.fetchone()['count']
            
            # India-related threats
            cursor.execute("SELECT COUNT(*) as count FROM threats WHERE india_related = TRUE")
            stats['india_threats'] = cursor.fetchone()['count']
            
            # By severity
            cursor.execute("SELECT severity, COUNT(*) as count FROM threats GROUP BY severity")
            stats['by_severity'] = {row['severity']: row['count'] for row in cursor.fetchall() if row['severity']}
            
            # By category
            cursor.execute("SELECT category, COUNT(*) as count FROM threats GROUP BY category")
            stats['by_category'] = {row['category']: row['count'] for row in cursor.fetchall() if row['category']}
            
            cursor.close()
            conn.close()
            
            return stats
            
        except Error as e:
            logger.error(f"Error getting stats: {e}")
            return {}