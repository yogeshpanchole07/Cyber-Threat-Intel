import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    
    # MySQL Configuration
    MYSQL_HOST = os.environ.get('MYSQL_HOST') or 'localhost'
    MYSQL_PORT = int(os.environ.get('MYSQL_PORT') or 3306)
    MYSQL_USER = os.environ.get('MYSQL_USER') or 'root'
    MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD') or '@aadi'  #  UPDATE THIS
    MYSQL_DATABASE = os.environ.get('MYSQL_DATABASE') or 'cyber_threats'
    
    #  YOUR CODEWORDS API KEY - NO RATE LIMITS!
    CODEWORDS_API_KEY = os.environ.get('CODEWORDS_API_KEY') or 'cwk-bf1284de7821f560a8f3632ba39e499482aaef855d444cb5504c18bce871fedc'
    
    # Use CodeWords for scraping?
    USE_CODEWORDS_SCRAPING = os.environ.get('USE_CODEWORDS_SCRAPING', 'false').lower() == 'true'
    
    # News sources (same as before)
    NEWS_SOURCES = [
        {
            'name': 'The Hacker News',
            'url': 'https://thehackernews.com/',
            'type': 'rss',
            'feed_url': 'https://feeds.feedburner.com/TheHackersNews'
        },
        {
            'name': 'Cybersecurity News',
            'url': 'https://cybersecuritynews.com/',
            'type': 'rss',
            'feed_url': 'https://cybersecuritynews.com/feed/'
        },
        {
            'name': 'Krebs on Security',
            'url': 'https://krebsonsecurity.com/',
            'type': 'rss',
            'feed_url': 'https://krebsonsecurity.com/feed/'
        },
        {
            'name': 'Bleeping Computer',
            'url': 'https://www.bleepingcomputer.com/',
            'type': 'rss',
            'feed_url': 'https://www.bleepingcomputer.com/feed/'
        }
    ]
    
    # Threat keywords
    THREAT_KEYWORDS = {
        'ransomware': ['ransomware', 'ransom', 'lockbit', 'ryuk', 'wannacry', 'blackcat'],
        'phishing': ['phishing', 'phish', 'spear phishing', 'credential theft', 'fake login'],
        'data_breach': ['data breach', 'data leak', 'database leak', 'exposed records', 'breach'],
        'ddos': ['ddos', 'denial of service', 'dos attack', 'botnet', 'amplification'],
        'malware': ['malware', 'trojan', 'virus', 'spyware', 'adware', 'backdoor'],
        'vulnerability': ['vulnerability', 'cve', 'zero-day', 'exploit', 'patch', 'security flaw'],
        'apt': ['apt', 'advanced persistent threat', 'nation-state', 'state-sponsored'],
        'india': ['india', 'indian', 'delhi', 'mumbai', 'bangalore', 'cert-in', 'bengaluru', 'chennai', 'hyderabad']
    }
    
    SEVERITY_LEVELS = {
        'critical': 10,
        'high': 7,
        'medium': 5,
        'low': 3,
        'info': 1
    }